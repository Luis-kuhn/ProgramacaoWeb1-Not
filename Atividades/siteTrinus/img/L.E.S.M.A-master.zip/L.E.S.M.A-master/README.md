#L.E.S.M.A

Não é surpresa que, no Brasil, pagamos valores astronômicos por um serviço de internet deixa muito a desejar. Na maioria das vezes, a velocidade que efetivamente recebemos não chega à metade do valor que pagamos.

Uma queda de 40% da velocidade por alguns minutos durante o dia é normal, ao passo que a mesma queda pela maior parte dele, não. Mas tenha certeza que se você apresentar o problema ao seu provedor, obterá uma resposta semelhante a primeira – a menos que apresente os registros de um programa como esse.

Tendo como base minha própria experiência, decidi criar o L.E.S.M.A, programa que realiza os tradicionais testes de internet minuto-a-minuto. Dessa forma, é possível obter um relatório preciso das velocidades alcançadas ao longo do dia e apresentar uma reclamação concisa ou até uma prova para futura ação judicial.
	
O código é inteiramente programado em Python 3. Para tanto, faça o download e instalação do interpretador para sua execução em  https://www.python.org/downloads/. 
	Em seguida, faça download do repositório inteiro presente em https://github.com/NatanSkywalker/L.E.S.M.A. Execute o L.E.S.M.A. - Fabrica de Noobs Speedtest.py e aguarde a entrada de dados. Nenhuma configuração adicional é necessária.
